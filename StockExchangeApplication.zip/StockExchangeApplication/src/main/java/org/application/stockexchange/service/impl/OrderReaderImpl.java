package org.application.stockexchange.service.impl;

import org.application.stockexchange.exception.InvalidOrderException;
import org.application.stockexchange.inputparser.OrderInputParser;
import org.application.stockexchange.model.Order;
import org.application.stockexchange.service.OrderReader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class OrderReaderImpl implements OrderReader {
    private OrderInputParser orderInputParser = new OrderInputParser();

    @Override
    public List<Order> read() {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

        List<Order> orders = new ArrayList<>();
        try {
            String line;
            while ((line = bufferedReader.readLine()) != null && line.length() != 0) {
                orders.add(orderInputParser.parse(line));
            }
            return orders;
        } catch (IOException | InvalidOrderException e) {
            throw new RuntimeException(e);
        }
    }
}
