package org.application.stockexchange.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;
import java.util.UUID;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class OrderExecuted {
    private SellOrder seller;
    private BuyOrder buyer;
    private int quantity;
    private BigDecimal sellPrice;
}
