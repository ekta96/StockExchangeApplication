package org.application.stockexchange.service.impl;

import org.application.stockexchange.exception.NoOrderExecutedException;
import org.application.stockexchange.model.*;
import org.application.stockexchange.service.OrderExecutionService;

import java.util.*;

public class OrderExecutionServiceImpl implements OrderExecutionService {
    private  Map<Stock, StocksByOrderType> stockByCompany = new HashMap<>();
    private List<OrderExecuted> orderExecutedList = new LinkedList<>();

    @Override
    public void processOrder(List<Order> orders) {
        for (Order order : orders) {
            if (!stockByCompany.containsKey(order.stock())) {
                stockByCompany.put(order.stock(), new StocksByOrderType());
            }
            stockByCompany.get(order.stock()).addOrder(order);
            List<OrderExecuted> executedList = executeTrade(stockByCompany.get(order.stock()).getBuyOrders(),stockByCompany.get(order.stock()).getSellOrders());
            orderExecutedList.addAll(executedList);
        }
    }

    private List<OrderExecuted> executeTrade(PriorityQueue<BuyOrder> buyOrders, PriorityQueue<SellOrder> sellOrders) {
        List<OrderExecuted> tradeExecutedList = new LinkedList<>();
        if (sellOrders != null && sellOrders.peek() != null && buyOrders != null && buyOrders.peek()!=null) {
            while (sellOrders.peek() != null && buyOrders.peek()!=null &&
                    (buyOrders.peek().price().compareTo(sellOrders.peek().price()) >= 0)) {
                BuyOrder buyOrder = buyOrders.peek();
                SellOrder sellOrder = sellOrders.peek();
                int quantityAvailableToBeSold = Math.min(buyOrder.quantity(), sellOrder.quantity());
                int quantityLeft;
                if (buyOrder.quantity() < sellOrder.quantity()) {
                    quantityLeft = sellOrder.quantity() - quantityAvailableToBeSold;
                    sellOrder.updateQuantity(quantityLeft);
                    sellOrders.add(sellOrder);
                } else if (buyOrder.quantity() > sellOrder.quantity()) {
                    quantityLeft = buyOrder.quantity() - quantityAvailableToBeSold;
                    buyOrder.updateQuantity(quantityLeft);
                    buyOrders.add(buyOrder);
                }
                buyOrders.poll();
                sellOrders.poll();
                tradeExecutedList.add(new OrderExecuted(sellOrder, buyOrder, quantityAvailableToBeSold, sellOrder.price()));
            }
        }
        return tradeExecutedList;
    }


    @Override
    public List<OrderExecuted> getExecutedTrades() throws NoOrderExecutedException {
        if(orderExecutedList.isEmpty()){
            throw new NoOrderExecutedException("No trade is executed for the orders");
        }
        return orderExecutedList;
    }

}
