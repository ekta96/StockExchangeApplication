package org.application.stockexchange.inputparser;

import lombok.extern.slf4j.Slf4j;
import org.application.stockexchange.enums.OrderType;
import org.application.stockexchange.exception.InvalidOrderException;
import org.application.stockexchange.model.Order;
import org.application.stockexchange.model.Stock;

import java.math.BigDecimal;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.StringTokenizer;

@Slf4j
public class OrderInputParser {
    private static final String SEPARATOR = " ";

    public Order parse(String line) throws InvalidOrderException {
        StringTokenizer stringTokenizer = new StringTokenizer(line, SEPARATOR);
        String id = stringTokenizer.nextToken();
        LocalTime orderTime = LocalTime.parse(stringTokenizer.nextToken(),
                DateTimeFormatter.ofPattern("HH:mm", Locale.getDefault()));
        String stockName = stringTokenizer.nextToken();
        Stock stock = new Stock(stockName);
        String type = stringTokenizer.nextToken();
        OrderType orderType = OrderType.valueOf(type.toUpperCase());
        int quantity = Integer.parseInt(stringTokenizer.nextToken());
        BigDecimal price = new BigDecimal(stringTokenizer.nextToken());
        return new Order.Builder().id(id)
                .time(orderTime)
                .stock(stock)
                .orderType(orderType)
                .quantity(quantity)
                .price(price)
                .build();

    }
}
