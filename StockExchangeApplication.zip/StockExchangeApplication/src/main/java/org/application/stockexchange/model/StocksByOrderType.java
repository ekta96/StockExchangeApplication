package org.application.stockexchange.model;

import lombok.Data;
import lombok.Setter;
import org.application.stockexchange.enums.OrderType;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

@Data
public class StocksByOrderType {
    PriorityQueue<BuyOrder> buyOrders = new PriorityQueue<>();
    PriorityQueue<SellOrder> sellOrders = new PriorityQueue<>();

    public void addOrder(Order order) {
        if (order instanceof BuyOrder) {
            buyOrders.add((BuyOrder) order);
        } else if (order instanceof SellOrder) {
            sellOrders.add((SellOrder) order);
        }
    }
}
