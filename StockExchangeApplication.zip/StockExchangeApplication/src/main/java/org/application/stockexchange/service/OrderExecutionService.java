package org.application.stockexchange.service;

import org.application.stockexchange.exception.NoOrderExecutedException;
import org.application.stockexchange.model.Order;
import org.application.stockexchange.model.OrderExecuted;

import java.util.List;
public interface OrderExecutionService {
   void processOrder(List<Order> orders);

   List<OrderExecuted> getExecutedTrades() throws NoOrderExecutedException;
}
