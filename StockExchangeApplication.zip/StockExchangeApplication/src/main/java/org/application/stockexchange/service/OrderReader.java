package org.application.stockexchange.service;

import org.application.stockexchange.model.Order;

import java.util.List;

public interface OrderReader {
    public List<Order> read();
}
