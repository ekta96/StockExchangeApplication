package org.application.stockexchange;

import lombok.extern.slf4j.Slf4j;
import org.application.stockexchange.controller.StockExchangeController;

@Slf4j
public class StockExchangeApplication {

    public static void main(String[] args) {
        StockExchangeController stockExchangeController = new StockExchangeController();
        stockExchangeController.run();
    }
}