package org.application.stockexchange.enums;

public enum OrderType {
    BUY("buy"),
    SELL("sell");

    private String orderRequestType;

    public String getOrderRequestType(){
        return orderRequestType;
    }
    OrderType(String orderRequestType){
        this.orderRequestType = orderRequestType;
    }
}
