package org.application.stockexchange.exception;

public class InvalidOrderException extends Exception{
    public InvalidOrderException(String message){
        super(message);
    }
}
