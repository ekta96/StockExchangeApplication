package org.application.stockexchange.exception;

public class NoOrderExecutedException extends RuntimeException{
    public NoOrderExecutedException(String message){
        super(message);
    }
}
