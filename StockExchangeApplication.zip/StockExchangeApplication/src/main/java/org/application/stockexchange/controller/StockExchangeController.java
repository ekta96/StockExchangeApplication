package org.application.stockexchange.controller;

import lombok.extern.slf4j.Slf4j;
import org.application.stockexchange.exception.NoOrderExecutedException;
import org.application.stockexchange.service.*;
import org.application.stockexchange.service.impl.OrderExecutionServiceImpl;
import org.application.stockexchange.service.impl.OrderReaderImpl;
import org.application.stockexchange.service.impl.OrderWriterImpl;

@Slf4j
public class StockExchangeController {
    private final OrderExecutionService orderExecutionService = new OrderExecutionServiceImpl();
    private final OrderReader orderReader = new OrderReaderImpl();
    private final OrderWriter orderWriter = new OrderWriterImpl();

    public void run() throws NoOrderExecutedException {
        log.info("Please place orders in the below given format");
        log.info("Format: <order-id> <time> <stock> <buy/sell> <qty> <price>");
        orderExecutionService.processOrder(orderReader.read());
        orderWriter.write(orderExecutionService.getExecutedTrades());
    }

}
