package org.application.stockexchange.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.application.stockexchange.enums.OrderType;
import org.application.stockexchange.exception.InvalidOrderException;

import java.math.BigDecimal;
import java.time.LocalTime;


public interface Order {
    Stock stock();

    BigDecimal price();

    int quantity();

    String id();

    LocalTime time();

    public static class Builder {
        Stock stock;
        BigDecimal price;
        int quantity;
        String id;
        LocalTime time;
        OrderType orderType;

        public Builder stock(Stock stock) {
            this.stock = stock;
            return this;
        }

        public Builder price(BigDecimal price) {
            this.price = price;
            return this;
        }

        public Builder price(int quantity) {
            this.quantity = quantity;
            return this;
        }

        public Builder id(String id) {
            this.id = id;
            return this;
        }

        public Builder time(LocalTime time) {
            this.time = time;
            return this;
        }
        public Builder orderType(OrderType orderType){
            this.orderType = orderType;
            return this;
        }
        public Builder quantity(int quantity){
            this.quantity = quantity;
            return this;
        }
        public  Order build() throws InvalidOrderException {
            if(orderType.equals(OrderType.BUY)){
             return new BuyOrder(this);
            }
            else if(orderType.equals(OrderType.SELL)){
                return new SellOrder(this);
            }else{
                throw new InvalidOrderException("Please enter the valid order type");
            }

        }
    }
}
