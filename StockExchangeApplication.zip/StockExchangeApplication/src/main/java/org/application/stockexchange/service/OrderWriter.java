package org.application.stockexchange.service;

import org.application.stockexchange.model.OrderExecuted;

import java.util.List;

public interface OrderWriter {
    public void write(List<OrderExecuted> orderExecutedList);
}
