package org.application.stockexchange.model;

import java.math.BigDecimal;
import java.time.LocalTime;

public final class BuyOrder implements Order,Comparable<Order>{
    private Stock stock;
    private BigDecimal price;
    private int quantity;
    private String id;
    private LocalTime time;

    BuyOrder (Order.Builder builder){
        this.stock = builder.stock;
        this.price = builder.price;
        this.quantity = builder.quantity;
        this.id = builder.id;
        this.time = builder.time;
    }

    @Override
    public Stock stock() {
        return stock;
    }

    @Override
    public BigDecimal price() {
        return price;
    }

    @Override
    public int quantity() {
        return quantity;
    }

    @Override
    public String id() {
        return id;
    }

    @Override
    public LocalTime time() {
        return time;
    }
    public void updateQuantity(int quantity){
        this.quantity = quantity;
    }
    @Override
    public int compareTo(Order order) {
        if ((this.price().compareTo(order.price())) < 0) {
            return 1;
        } else if ((this.price().compareTo(order.price())) == 0) {
            return this.time().compareTo(order.time());
        }
        return -1;
    }
}
