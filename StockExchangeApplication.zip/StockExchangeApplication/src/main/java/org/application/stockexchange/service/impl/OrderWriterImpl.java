package org.application.stockexchange.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.application.stockexchange.model.OrderExecuted;
import org.application.stockexchange.service.OrderWriter;

import java.util.List;

@Slf4j
public class OrderWriterImpl implements OrderWriter {

    @Override
    public void write(List<OrderExecuted> orderExecutedList) {
        if (orderExecutedList.isEmpty()) {
            log.info("Please place more orders, for trade to get executed");
        }
        orderExecutedList.forEach(orderExecuted ->
            log.info(orderExecuted.getSeller().id() + " " + orderExecuted.getQuantity()
                    + " " + orderExecuted.getSellPrice() + " " + orderExecuted.getBuyer().id())
        );
    }
}